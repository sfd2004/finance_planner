import sqlite3
from config import DB_PATH
from datetime import datetime

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            notifications_enabled BOOLEAN DEFAULT 1
        )""")
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS budgets (
            user_id INTEGER,
            category TEXT,
            amount INTEGER,
            PRIMARY KEY (user_id, category),
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
        )""")
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            amount INTEGER,
            category TEXT,
            date TEXT,
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
        )""")
        conn.commit()


def add_user(user_id: int):
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (user_id,))
        conn.commit()


def set_budget(user_id: int, category: str, amount: int):
    add_user(user_id)
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO budgets (user_id, category, amount)
            VALUES (?, ?, ?)
            ON CONFLICT(user_id, category) DO UPDATE SET amount=excluded.amount
        """, (user_id, category, amount))
        conn.commit()


def log_transaction(user_id: int, amount: int, category: str):
    add_user(user_id)
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        now = datetime.now().isoformat()
        cursor.execute("""
            INSERT INTO logs (user_id, amount, category, date)
            VALUES (?, ?, ?, ?)
        """, (user_id, amount, category, now))
        conn.commit()


def get_summary(user_id: int):
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT category, SUM(amount)
            FROM logs
            WHERE user_id = ?
            GROUP BY category
        """, (user_id,))
        rows = cursor.fetchall()

        cursor.execute("""
            SELECT category, amount FROM budgets
            WHERE user_id = ?
        """, (user_id,))
        budgets = {row[0]: row[1] for row in cursor.fetchall()}

        return rows, budgets
