from aiogram import Router, types
from aiogram.filters import Command
from db import set_budget, log_transaction, get_summary, add_user

router = Router()

@router.message(Command("start"))
async def cmd_start(message: types.Message):
    add_user(message.from_user.id)
    await message.answer("Hi! I'll help you keep track of your finances. Use /help for the list of commands.")

@router.message(Command("help"))
async def cmd_help(message: types.Message):
    await message.answer("""
 Commands:
• /start — start
• /help — list of commands
• /config <category> <summ> — set a budget
• /log <+/-сумма> <category> — record income/expense
• /summary — show balance by categories
""")

@router.message(Command("config"))
async def cmd_config(message: types.Message):
    args = message.text.strip().split()
    if len(args) != 3:
        return await message.answer(" Format: /config <category> <summ>")

    _, category, amount = args
    try:
        amount = int(amount)
    except ValueError:
        return await message.answer(" The sum must be a number ")

    set_budget(message.from_user.id, category, amount)
    await message.answer(f" Budget for the category '{category}' set: {amount}₸")

@router.message(Command("log"))
async def cmd_log(message: types.Message):
    args = message.text.strip().split()
    if len(args) != 3:
        return await message.answer(" Format: /log <+/-summ> <category>")

    _, amount_str, category = args
    try:
        amount = int(amount_str)
    except ValueError:
        return await message.answer(" The sum must be a signed number +/-")

    log_transaction(message.from_user.id, amount, category)
    await message.answer(f" Recorded: {amount}₸ in category '{category}'")

@router.message(Command("summary"))
async def cmd_summary(message: types.Message):
    user_id = message.from_user.id
    rows, budgets = get_summary(user_id)

    if not rows:
        return await message.answer("There are no records yet")

    lines = [" Current Balance:\n"]
    for category, total in rows:
        budget = budgets.get(category)
        line = f"• {category}: {total}₸"
        if budget:
            line += f" / Budget: {budget}₸"
            if total > budget:
                line += " ⚠️"
        lines.append(line)

    await message.answer("\n".join(lines))
