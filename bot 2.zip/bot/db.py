import sqlite3
from config import DB_PATH
from datetime import datetime

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            notifications_enabled BOOLEAN DEFAULT 1
        )""")
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS budgets (
            user_id INTEGER,
            category TEXT,
            amount INTEGER,
            current_balance INTEGER,
            PRIMARY KEY (user_id, category),
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
        )""")
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            amount INTEGER,
            category TEXT,
            date TEXT,
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
        )""")
        conn.commit()


def add_user(user_id: int):
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (user_id,))
        conn.commit()


def set_budget(user_id: int, category: str, amount: int):
    add_user(user_id)
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO budgets (user_id, category, amount, current_balance)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id, category) DO UPDATE SET amount=excluded.amount
        """, (user_id, category, amount, amount))
        conn.commit()


def check_current_balance(user_id: int, amount: int, category: str):
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT current_balance FROM budgets WHERE category = ? AND user_id = ?
        """, (category, user_id))
        return cursor.fetchone()[0]

def change_current_balance(user_id: int, amount: int, category: str, action: str):
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        now = datetime.now().isoformat()
        current_balance = int(check_current_balance(user_id, amount, category))

        if action == '-':
            new_balance = current_balance - amount
        elif action == '+':
            new_balance = current_balance + amount

        cursor.execute("""
            UPDATE budgets SET current_balance = ? WHERE category = ? AND user_id = ?
        """, (new_balance, category, user_id))
        conn.commit()

def log_transaction(user_id: int, amount: int, category: str):
    add_user(user_id)
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        now = datetime.now().isoformat()
        cursor.execute("""
            INSERT INTO logs (user_id, amount, category, date)
            VALUES (?, ?, ?, ?)
        """, (user_id, amount, category, now))
        conn.commit()

def get_summary(user_id: int):
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()

        cursor.execute("""
            SELECT category, current_balance, amount FROM budgets
            WHERE user_id = ?
        """, (user_id,))
        budget_data = cursor.fetchall()
        budgets = {row[0]: (row[1], row[2]) for row in budget_data}
        return budgets
