import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = '8121164567:AAGmuwvJdyfYwWwpxqai0pIjwwhLGhOCCgo'
DB_PATH = "database.db"
